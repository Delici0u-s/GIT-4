To run the project:
    
    `mvn clean javafx:run`