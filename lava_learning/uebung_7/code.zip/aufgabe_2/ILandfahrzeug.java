public interface ILandfahrzeug extends IFahrzeug {
  void fahren();
}
