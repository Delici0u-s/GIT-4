public interface IWasserfahrzeug extends IFahrzeug {
  void schwimmen();
}
