public interface IFahrzeug {
  void starten();

  void stoppen();
}
