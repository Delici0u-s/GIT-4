public class Transportmittel {
  public void durchfuehrenWartung() {
    System.out.println("Wartung wird durchgeführt");
  }

}
