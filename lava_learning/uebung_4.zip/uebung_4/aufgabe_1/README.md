compile with `javac Person.java`  

execute with `java Person`