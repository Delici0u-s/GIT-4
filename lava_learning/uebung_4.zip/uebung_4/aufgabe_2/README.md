compile with `javac BankAccount.java`  

execute with `java BankAccount`