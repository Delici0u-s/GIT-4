compile with `javac Main.java`  

execute with `java Main <WordYouWantToCheck>`